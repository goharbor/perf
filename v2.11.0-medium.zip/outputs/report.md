
### Harbor Performance Testing Report


| API | Avg | Min | Med | Max | P(90) | P(95) | Success Rate | Iterations Rate |
|-----|-----|-----|-----|-----|-------|-------|--------------|-----------------|
| get-artifact-by-digest | 273.03ms | 4.75ms | 143.8ms | 759.62ms | 719.43ms | 744.88ms | 100% | 476.10/s |
| get-artifact-by-tag | 70.45ms | 4.38ms | 34.08ms | 178.76ms | 156.26ms | 158.2ms | 100% | 4219.87/s |
| get-catalog | 22.04s | 9.37s | 21.43s | 34.21s | 25.22s | 25.4s | 100% | 21.46/s |
| get-project | 215.51ms | 8.75ms | 118.87ms | 633.16ms | 514.36ms | 586.31ms | 100% | 1450.79/s |
| get-repository | 65.24ms | 5.96ms | 62.69ms | 366.16ms | 134ms | 137.36ms | 100% | 2438.99/s |
| get-v2 | 57.04ms | 4.04ms | 36.18ms | 144.84ms | 136.69ms | 141.32ms | 100% | 6852.87/s |
| list-artifact-tags | 546.34ms | 7.24ms | 506.71ms | 1.22s | 1.06s | 1.14s | 100% | 806.36/s |
| list-artifacts | 7.78s | 2.41s | 7.85s | 16.41s | 10.76s | 11.2s | 100% | 60.91/s |
| list-audit-logs | 253.56s | 7.85s | 253.67s | 566.69s | 495.63s | 525.25s | 100% | 1.74/s |
| list-project-logs | 2.26s | 9.01ms | 2.28s | 4.6s | 4.55s | 4.58s | 100% | 217.05/s |
| list-project-members | 288.97ms | 4.27ms | 214.74ms | 730.22ms | 710.97ms | 720.09ms | 100% | 1366.78/s |
| list-projects | 1.06s | 18.77ms | 1s | 2.42s | 1.84s | 2.04s | 100% | 396.24/s |
| list-quotas | 312.11ms | 84.92ms | 291.7ms | 428.36ms | 408.34ms | 410.82ms | 100% | 1356.68/s |
| list-repositories | 958.99ms | 31.82ms | 1.03s | 1.87s | 1.79s | 1.82s | 100% | 468.49/s |
| list-users | 91.93ms | 4.73ms | 56.04ms | 193.34ms | 180.73ms | 185.62ms | 100% | 4790.70/s |
| pull-artifacts-from-different-projects | 3.5s | 340.57ms | 3.23s | 8.03s | 5.84s | 6.91s | 100% | 7.46/s |
| pull-artifacts-from-same-project | 29.93s | 242.91ms | 26.68s | 77.69s | 62.5s | 69.33s | 100% | 12.75/s |
| push-artifacts-to-different-projects | 25.38s | 13.39s | 25.23s | 46.75s | 32.58s | 35.18s | 100% | 7.30/s |
| push-artifacts-to-same-projects | 25.04s | 11.78s | 24.29s | 48.38s | 35.34s | 39s | 100% | 7.17/s |
| search-users | 75.62ms | 8.56ms | 42.19ms | 161.19ms | 151.61ms | 155.49ms | 100% | 6021.22/s |
