
### Harbor Performance Testing Report


| API | Avg | Min | Med | Max | P(90) | P(95) | Success Rate | Iterations Rate |
|-----|-----|-----|-----|-----|-------|-------|--------------|-----------------|
| get-artifact-by-digest | 87.76ms | 5.45ms | 85.29ms | 235.53ms | 175.9ms | 216.26ms | 100% | 675.71/s |
| get-artifact-by-tag | 126.48ms | 5.05ms | 118.67ms | 328.89ms | 296.84ms | 315.19ms | 100% | 2691.91/s |
| get-catalog | 1.53s | 180.4ms | 1.25s | 3.56s | 3.11s | 3.42s | 100% | 280.41/s |
| get-project | 81.87ms | 8.02ms | 79.46ms | 232.02ms | 158.63ms | 208.12ms | 100% | 3874.16/s |
| get-repository | 98.1ms | 8.67ms | 89.76ms | 273.55ms | 194.63ms | 231.79ms | 100% | 3271.32/s |
| get-v2 | 35.86ms | 1.97ms | 21.18ms | 118.88ms | 88.83ms | 113.68ms | 100% | 8359.15/s |
| list-artifact-tags | 137.91ms | 10.23ms | 134.04ms | 380.13ms | 257.98ms | 343.93ms | 100% | 2583.80/s |
| list-artifacts | 797.28ms | 184.78ms | 700.16ms | 1.52s | 1.13s | 1.18s | 100% | 587.38/s |
| list-audit-logs | 1.95s | 123.89ms | 1.78s | 4.42s | 3.46s | 3.84s | 100% | 218.76/s |
| list-project-logs | 73.34ms | 4.81ms | 39.62ms | 198.76ms | 147.45ms | 175.2ms | 100% | 4985.79/s |
| list-project-members | 98.7ms | 4.39ms | 101.09ms | 271.96ms | 222.53ms | 251.6ms | 100% | 3649.08/s |
| list-projects | 447.17ms | 24.38ms | 399.28ms | 1.06s | 812.76ms | 891.2ms | 100% | 908.09/s |
| list-quotas | 298.12ms | 171.61ms | 267.78ms | 427.34ms | 389.51ms | 394.43ms | 100% | 1372.44/s |
| list-repositories | 176.28ms | 9.88ms | 118.92ms | 459.04ms | 420.74ms | 441.63ms | 100% | 2157.65/s |
| list-users | 58.7ms | 4.29ms | 21.42ms | 169.13ms | 139.45ms | 150.13ms | 100% | 5328.27/s |
| pull-artifacts-from-different-projects | 3.45s | 403.48ms | 3.07s | 8.94s | 6.42s | 7.27s | 100% | 18.61/s |
| pull-artifacts-from-same-project | 29.63s | 571.18ms | 25.58s | 76.98s | 61.46s | 68.94s | 100% | 12.89/s |
| push-artifacts-to-different-projects | 6.44s | 1.07s | 6.06s | 13.5s | 9.86s | 11.83s | 100% | 16.41/s |
| push-artifacts-to-same-projects | 25.65s | 4.09s | 23.89s | 54.57s | 40.82s | 48.22s | 100% | 9.70/s |
| search-users | 61.78ms | 3.43ms | 36.53ms | 145.58ms | 132.61ms | 135.96ms | 100% | 6440.69/s |
